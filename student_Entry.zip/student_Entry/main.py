import tkinter as tk
from tkinter import ttk
import mysql.connector
from tkinter import messagebox



# Establish a connection to MySQL
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="student_management"
)

# Create a cursor object to execute SQL queries
cursor = db.cursor()


# Function to save student data into the database
def save_student():
    full_name = entry_full_name.get()
    school_id = entry_school_id.get()
    course = var_course.get()

    selected_item = treeview.selection()

    # If an item is selected, update the existing data
    if selected_item:
        student_id = treeview.item(selected_item)['values'][0]

        # Execute the SQL query to update the student data
        sql = "UPDATE data SET full_name=%s, school_id=%s, course=%s WHERE id=%s"
        values = (full_name, school_id, course, student_id)
        cursor.execute(sql, values)

        # Commit the changes to the database
        db.commit()

        messagebox.showinfo("Update", "Data updated successfully.")
    else:
        # Execute the SQL query to insert the student data
        sql = "INSERT INTO data (full_name, school_id, course) VALUES (%s, %s, %s)"
        values = (full_name, school_id, course)
        cursor.execute(sql, values)

        # Commit the changes to the database
        db.commit()

        messagebox.showinfo("Save", "Data saved successfully.")

    # Clear the entry fields
    entry_full_name.delete(0, tk.END)
    entry_school_id.delete(0, tk.END)
    var_course.set(course_options[0])  # Reset the dropdown to the default option

    refresh_treeview()


# Function to refresh the treeview with the updated data
def refresh_treeview():
    # Clear the existing data in the treeview
    treeview.delete(*treeview.get_children())

    # Execute the SQL query to retrieve all the student data
    cursor.execute("SELECT * FROM data")
    rows = cursor.fetchall()

    # Insert the student data into the treeview
    for row in rows:
        treeview.insert("", tk.END, values=row)


# Function to delete student data from the database
def delete_student():
    # Get the selected item from the treeview
    selected_item = treeview.selection()
    if selected_item:
        # Get the ID of the selected item
        student_id = treeview.item(selected_item)['values'][0]

        # Execute the SQL query to delete the student data
        sql = "DELETE FROM data WHERE id=%s"
        values = (student_id,)
        cursor.execute(sql, values)

        # Commit the changes to the database
        db.commit()

        refresh_treeview()


# Function to search for student data by name or school ID
def search_student():
    keyword = entry_search.get()
    if keyword:
        # Execute the SQL query to search for student data
        sql = "SELECT * FROM data WHERE full_name LIKE %s OR school_id LIKE %s"
        values = (f"%{keyword}%", f"%{keyword}%")
        cursor.execute(sql, values)
        rows = cursor.fetchall()

        # Clear the existing data in the treeview
        treeview.delete(*treeview.get_children())

        # Insert the search results into the treeview
        for row in rows:
            treeview.insert("", tk.END, values=row)


# Function to handle double-click event on treeview
def edit_cell(event):
    item = treeview.selection()
    column = treeview.identify_column(event.x)
    if item and column:
        cell_value = treeview.item(item)['values'][int(column[1:]) - 1]
        edit_entry(item, column, cell_value)


# Function to create an entry widget for cell editing
def edit_entry(item, column, cell_value):
    bbox = treeview.bbox(item, column)
    x, y, width, height = bbox

    entry = tk.Entry(treeview, validate="focusout", validatecommand=lambda: update_cell(item, column, entry.get()))
    entry.insert(0, cell_value)
    entry.place(x=x, y=y, width=width, height=height)
    entry.focus_set()


# Function to update the cell value in the treeview and database
def update_cell(item, column, new_value):
    column_index = int(column[1:]) - 1
    item_values = treeview.item(item)['values']
    student_id = item_values[0]

    if item_values[column_index] != new_value:
        item_values[column_index] = new_value

        # Construct the column name based on the selected column index
        columns = ["ID", "full_name", "school_id", "course"]
        column_name = columns[column_index]

        # Execute the SQL query to update the student data
        sql = f"UPDATE data SET `{column_name}` = %s WHERE id = %s"
        values = (new_value, student_id)

        cursor.execute(sql, values)

        # Commit the changes to the database
        db.commit()

        messagebox.showinfo("Update", "Data updated successfully.")

    refresh_treeview()  # Refresh the treeview with the updated data
    treeview.focus_set()
    entry.destroy()  # Remove the entry widget


# Function to create an entry widget for cell editing
def edit_entry(item, column, cell_value):
    bbox = treeview.bbox(item, column)
    x, y, width, height = bbox

    global entry
    entry = tk.Entry(treeview, validate="focusout", validatecommand=lambda: update_cell(item, column, entry.get()))
    entry.insert(0, cell_value)
    entry.place(x=x, y=y, width=width, height=height)
    entry.focus_set()




# Create the main window
window = tk.Tk()
window.title("Student Entry")
window.geometry("725x500")
tab_main = ttk.Notebook(window)

# Create a frame for the "Admin Details" tab
frame_admin = ttk.Frame(tab_main)
tab_main.add(frame_admin, text="Admin Details")
tab_main.grid(row=0, column=0)

ss = ttk.Frame(tab_main)
tab_main.add(ss, text="Student Entry")

# Create labels and entry fields
label_full_name = tk.Label(ss, text="Full Name:")
label_full_name.grid(row=1, column=0)
entry_full_name = tk.Entry(ss)
entry_full_name.grid(row=1, column=1)

label_school_id = tk.Label(ss, text="School ID:")
label_school_id.grid(row=2, column=0)
entry_school_id = tk.Entry(ss)
entry_school_id.grid(row=2, column=1)

label_course = tk.Label(ss, text="Course:")
label_course.grid(row=3, column=0)

# Define the course options for the dropdown menu
course_options = [
    "Bachelor of Science in Information Tech",
    "Bachelor of Computer Science",
    "Bachelor of Science Criminology"
]

var_course = tk.StringVar(ss)
var_course.set(course_options[0])  # Set the default option

# Create the dropdown menu
dropdown_course = tk.OptionMenu(ss, var_course, *course_options)
dropdown_course.grid(row=3, column=1)

title1 = tk.Label(frame_admin, text="Dashboard")
title1.grid(row=0, column=0)

# Create the save button
button_save = tk.Button(ss, text="Save", command=save_student)
button_save.grid(row=4, column=1)

button_delete = tk.Button(frame_admin, text="Delete", command=delete_student)
button_delete.grid(row=4, column=2, padx=5, pady=5)

button_refresh = tk.Button(frame_admin, text="Refresh", command=refresh_treeview)
button_refresh.grid(row=0, column=2, padx=5, pady=5)


# Create search label, entry field, and button
label_search = tk.Label(frame_admin, text="Search:")
label_search.grid(row=1, column=0, padx=5, pady=5)
entry_search = tk.Entry(frame_admin)
entry_search.grid(row=1, column=1, padx=5, pady=5, ipadx=120, ipady=3)
button_search = tk.Button(frame_admin, text="Search", command=search_student)
button_search.grid(row=1, column=2, padx=5, pady=5)


treeview = ttk.Treeview(frame_admin, columns=("ID", "Full Name", "School ID", "Course"), show="headings")
# Bind double-click event to treeview
treeview.bind("<Double-1>", edit_cell)
treeview.heading("ID", text="ID")
treeview.column("ID", width=150, anchor="center")  # Set the width of the ID column
treeview.heading("Full Name", text="Full Name")
treeview.column("Full Name", width=150, anchor="center")  # Set the width of the Full Name column
treeview.heading("School ID", text="School ID")
treeview.column("School ID", width=100, anchor="center")  # Set the width of the School ID column
treeview.heading("Course", text="Course")
treeview.column("Course", width=300, anchor="center")  # Set the width of the Course column
treeview.grid(row=3, column=0, padx=10, pady=10, columnspan=3)

# Refresh the treeview to display the initial data
refresh_treeview()

# Start the Tkinter event loop
window.mainloop()
